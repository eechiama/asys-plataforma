/**
 * @file	AP_UART.c
 * @brief	x
 * @author	Esteban E. Chiama
 * @date	Aug 12, 2020
 * @version	1.0
 */

// ===================================
//	Includes
// ===================================

#include <AP_UART.h>
#include <HAL_UART.h>
#include <RingBuffer.h>

// ===================================
//	Private constants
// ===================================

#define	UART_BAUDRATE	115200

// ===================================
//	Private datatypes
// ===================================

// ===================================
//	Private tables
// ===================================

// ===================================
//	Private function headers
// ===================================
static void rx_callback(void);
static void tx_callback(void);

/**
 * @brief		Performs 'byte_amount' byte puts from 'byte_array'
 * 				into the ring buffer that is for TX uart communication.
 * @return		true on success, false if the tx ring buffer does not have enough space.
 */
unsigned char TxBufferPutArray(const unsigned char *byte_array, unsigned int byte_amount);

// ===================================
//	Shared global variables
// ===================================

// ===================================
//	Private global variables
// ===================================

static const hal_uart_config_t uart_config = {
	.data_length = HAL_UART_DATALEN_8BIT,
	.parity = HAL_UART_PARITY_NO_PARITY,
	.stop_bits = HAL_UART_STOPLEN_1BIT,
	.oversampling = HAL_UART_OVERSAMPLING_X16,
	.clock_selection = HAL_SYSCON_PERIPHERAL_CLOCK_SEL_FRG0,
	.baudrate = UART_BAUDRATE,
	.tx_portpin = TX_PORT_PIN,
	.rx_portpin = RX_PORT_PIN,
	.rx_ready_callback = rx_callback,
	.tx_ready_callback = tx_callback
};

static char mem_buffer[UART_BUFFERS_MEM_SIZE];

static volatile RingBuffer rBuf_RX = {
		.memory_buffer = &mem_buffer[0],
		.data_size = sizeof(char),
		.element_amount = UART_BUFFERS_MEM_SIZE/2
};

static volatile RingBuffer rBuf_TX = {
		.memory_buffer = &mem_buffer[UART_BUFFERS_MEM_SIZE/2],
		.data_size = sizeof(char),
		.element_amount = UART_BUFFERS_MEM_SIZE/2
};

static volatile uint8_t f_Transmitting = 0;

// ===================================
//	Private functions
// ===================================

static void rx_callback(void){
	unsigned int data;
	if( hal_uart_rx_data(UART_NUMBER, &data) == HAL_UART_RX_RESULT_OK ){
		RingBufferPutElement((RingBuffer *)&rBuf_RX, (void *)&data);
	}
}

static void tx_callback(void){
	unsigned char data_to_send = 0;

	if( !RingBufferGetAvailableElements((void *)&rBuf_TX) ){
		f_Transmitting = 0;
	}
	else{
		RingBufferPopElement((RingBuffer *)&rBuf_TX, (void *)&data_to_send);
		hal_uart_tx_data(UART_NUMBER, data_to_send);
	}
}

unsigned char TxBufferPutArray(const unsigned char *byte_array, unsigned int byte_amount){
	unsigned char result = 0;
	unsigned int inx_data_byte = 0;
	unsigned int free_elements = RingBufferGetAvailableSpace((const RingBuffer *)&rBuf_TX);

	if( free_elements >=  byte_amount){
		while( inx_data_byte < byte_amount ){
			RingBufferPutElement((RingBuffer *)&rBuf_TX, (void *)((char *)byte_array + inx_data_byte) );
			inx_data_byte++;
		}
		result = 1;
	}

	return result;
}

// ===================================
//	Public functions
// ===================================

void init_uart(void){
	hal_uart_init(UART_NUMBER, &uart_config);
	RingBufferInit((RingBuffer *)&rBuf_RX);
	RingBufferInit((RingBuffer *)&rBuf_TX);
}

transmit_bytes_result_en TransmitBytes(const unsigned char *byte_array, unsigned int byte_amount){

	unsigned char data_to_send;
	transmit_bytes_result_en result = TRANSMIT_BYTES_ERR;

	if( TxBufferPutArray(byte_array, byte_amount) ){
		result = TRANSMIT_BYTES_ONGOING;
		if( !f_Transmitting ){
			f_Transmitting = 1;
			RingBufferPopElement((RingBuffer *)&rBuf_TX, (void *)&data_to_send);
			hal_uart_tx_data(UART_NUMBER, data_to_send);
			result = TRANSMIT_BYTES_STARTED;
		}
	}

	return result;
}

int wrapper_byteReceiver(unsigned char *data){
	return RingBufferPopElement((void *)&rBuf_RX, (void *)&(*data));
}
