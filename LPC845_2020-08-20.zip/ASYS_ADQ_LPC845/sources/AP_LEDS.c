/*
 * AP_LEDS.c
 *
 *  Created on: Apr 1, 2020
 *      Author: stv
 */

// ===================================
//	Includes
// ===================================

#include <AP_LEDS.h>
#include <HAL_GPIO.h>

// ===================================
//	Private constants
// ===================================

// ===================================
//	Private datatypes
// ===================================

// ===================================
//	Private tables
// ===================================

static const uint8_t led_port_pin[LED_QTY] = {
		HAL_GPIO_PORTPIN_1_0,
		HAL_GPIO_PORTPIN_1_1,
		HAL_GPIO_PORTPIN_1_2
};

// ===================================
//	Shared global variables
// ===================================

// ===================================
//	Private global variables
// ===================================

// ===================================
//	Private function headers
// ===================================

// ===================================
//	Private functions
// ===================================

// ===================================
//	Public functions
// ===================================

void leds_off(void){
	uint8_t inx = 0;

	while( inx < LED_QTY ){
		hal_gpio_set_dir(led_port_pin[inx], HAL_GPIO_DIR_OUTPUT, LED_OFF);
		inx++;
	}
}

void init_leds(void){
	// All leds share the same port
	hal_gpio_init(LED_PORT);
	leds_off();
}

void set_led(led_select_en led_selection){
	hal_gpio_clear_pin( led_port_pin[led_selection] );
}

void clear_led(led_select_en led_selection){
	hal_gpio_set_pin( led_port_pin[led_selection] );
}

void toggle_led(led_select_en led_selection){
	hal_gpio_toggle_pin(led_port_pin[led_selection] );
}
