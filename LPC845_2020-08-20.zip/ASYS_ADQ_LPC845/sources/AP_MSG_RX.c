/**
 * @file	AP_MSG_RX.c
 * @brief	x
 * @author	Esteban E. Chiama
 * @date	Apr 4, 2020
 * @version	1.0
 */

// ===================================
//	Includes
// ===================================

#include <AP_MSG_RX.h>
#include <stddef.h>				// NULL definition

/* for debug stuff */
#include <AP_UART.h>

// ===================================
//	Private constants
// ===================================

// ===================================
//	Private datatypes
// ===================================

typedef enum {
	WAITING_MSG,
	RECEIVING_MSG,
} states_en;

/* for debug stuff */

typedef enum{
	POP_TRUE = 0,
	BEGAN_WORD,
	OVERFLOW,
	END_WORD
} debug_location_en;

static const char * debug_msg[4] = {
	"@rP\n",
	"@rB\n",
	"@rO\n",
	"@rE\n"
};

// ===================================
//	Private tables
// ===================================

// ===================================
//	Shared global variables
// ===================================

// ===================================
//	Private global variables
// ===================================

// ===================================
//	Private function headers
// ===================================

// ===================================
//	Private functions
// ===================================

// ===================================
//	Public functions
// ===================================

void RX_Messages_SM(const msg_rx_protocol_t * protocol) {

	static states_en state = WAITING_MSG;
	static unsigned char inx_msg_rx = 0;
	unsigned char data_rx;

	if ( protocol->byte_receiver(&data_rx) == 0 ) {
		// MdE: Análisis de la trama recibida
		switch ( state ) {

			case WAITING_MSG:
				// Check for start of command message by protocol character.
				if ( (char)data_rx == protocol->symbol_msg_start ) {
					inx_msg_rx = 0;
					state = RECEIVING_MSG;
					TransmitBytes((unsigned char *)debug_msg[BEGAN_WORD], DEBUG_MSG_LENGTH);
				}
				break;

			case RECEIVING_MSG:
				// Message not yet finished by protocol character, store character.
				if ( (char)data_rx != protocol->symbol_msg_end ) {
					protocol->msg_buffer[inx_msg_rx] = (char)data_rx;
					inx_msg_rx++;
					// overflow protection
					if (inx_msg_rx > (protocol->msg_max_length - 1) ) {
						state = WAITING_MSG;
						TransmitBytes((unsigned char *)debug_msg[OVERFLOW], DEBUG_MSG_LENGTH);
					}
					break;
				}
				// Message is finished by protocol ending character.
				if ( (char)data_rx == protocol->symbol_msg_end ) {
					protocol->msg_reader(protocol->msg_buffer);
					state = WAITING_MSG;
					TransmitBytes((unsigned char *)debug_msg[END_WORD], DEBUG_MSG_LENGTH);
				}
				break;
		}
	}
}
