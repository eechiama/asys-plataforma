/*
 * AP_LEDS.h
 *
 *  Created on: Apr 1, 2020
 *      Author: stv
 */

#ifndef AP_LEDS_H_
#define AP_LEDS_H_

// ===================================
//	Includes
// ===================================

// ===================================
//	Constants
// ===================================

#define		LED_OFF		1
#define		LED_ON		0

#define		LED_QTY		3
#define		LED_PORT	1

// ===================================
//	Datatypes
// ===================================

// Los valores del enum deben coincidir con los elementos
// de led_port_pin[LED_QTY] que se halla en ap_leds.c
typedef enum {
	LED_GREEN = 0,
	LED_BLUE,
	LED_RED
} led_select_en;

// ===================================
//	Tables
// ===================================

// ===================================
//	Shared global variables
// ===================================

// ===================================
//	Function headers
// ===================================

void leds_off(void);

void init_leds(void);

void set_led(led_select_en led);

void clear_led(led_select_en led);

void toggle_led(led_select_en led);

#endif /* AP_LEDS_H_ */
