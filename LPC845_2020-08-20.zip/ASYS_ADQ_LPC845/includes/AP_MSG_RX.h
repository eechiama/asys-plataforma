/**
 * @file	AP_MSG_RX.h
 * @brief	x
 * @author	Esteban E. Chiama
 * @date	Apr 4, 2020
 * @version	1.0
 */

#ifndef AP_MSG_RX_H_
#define AP_MSG_RX_H_

// ===================================
//	Includes
// ===================================

// ===================================
//	Constants
// ===================================

#define		DEFAULT_MSG_START_SYMBOL		'$'
#define		DEFAULT_MSG_END_SYMBOL			'#'

// ===================================
//	Datatypes
// ===================================

typedef struct
{
	char symbol_msg_start;
	char symbol_msg_end;
	unsigned char * const msg_buffer; /** Buffer provisto por el usuario donde se guardarán los mensajes para su análisis */
	unsigned char msg_max_length; /** tamaño de msg_buffer */
	int (*byte_receiver)(unsigned char *);	/** Función que obtiene un byte del buffer de recepción del método que se use, por ej UART.*/
	void (*msg_reader)(const unsigned char *msg); /** Función del usuario que se encarga de interpretar y hacer algo con el mensaje válido recibido*/
} msg_rx_protocol_t;

// ===================================
//	Tables
// ===================================

// ===================================
//	Shared global variables
// ===================================

// ===================================
//	Function headers
// ===================================

/**
 * @brief		State machine that checks incoming messages for commands
 * 				and in consequence sets the shared global variable 'command'.
 * 				Capability to send debug messages.
 */
void RX_Messages_SM(const msg_rx_protocol_t * protocol);

#endif /* AP_MSG_RX_H_ */
