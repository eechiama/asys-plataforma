/**
 * @file	AP_UART.h
 * @brief	x
 * @author	Esteban E. Chiama
 * @date	Aug 12, 2020
 * @version	1.0
 */

#ifndef AP_UART_H_
#define AP_UART_H_

// ===================================
//	Includes
// ===================================

// ===================================
//	Constants
// ===================================

#define		UART_NUMBER			0

// These pins connect to the debugger serial interface
#define		RX_PORT_PIN			HAL_GPIO_PORTPIN_0_24
#define		TX_PORT_PIN			HAL_GPIO_PORTPIN_0_25

#define 	TX_BUFFER_LENGTH	32
#define 	RX_BUFFER_LENGTH	32

#define		UART_BUFFERS_MEM_SIZE	128

// Cosas Random
#define 	DEBUG_MSG_LENGTH	4

// ===================================
//	Datatypes
// ===================================

typedef enum{
	TRANSMIT_BYTES_ERR = 0,
	TRANSMIT_BYTES_ONGOING,
	TRANSMIT_BYTES_STARTED
}transmit_bytes_result_en;

// ===================================
//	Tables
// ===================================

// ===================================
//	Shared global variables
// ===================================

// ===================================
//	Function headers
// ===================================

/**
 * @brief		init_uart
 */
void init_uart(void);

/**
 * @brief		Queues up bytes from a byte array into the transmission queue.
 * 				If there's no transmission on-going, it starts.
 * @param[in]	byte_array:		pointer to byte vector.
 * @param[in]	byte_amount:	amount of bytes to be sent.
 * @return		x
 */
transmit_bytes_result_en TransmitBytes(const unsigned char *byte_array, unsigned int byte_amount);

// Wrapper para ap_msg_protocol.c
int wrapper_byteReceiver(unsigned char *data);

#endif /* AP_UART_H_ */
